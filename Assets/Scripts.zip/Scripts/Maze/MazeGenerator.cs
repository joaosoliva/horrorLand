﻿using UnityEngine;
using System.Collections.Generic;

public class MazeGenerator : MonoBehaviour
{
	[Header("Maze Settings")]
	public int width = 20;
	public int height = 20;
	public float cellSize = 2f;
	public float wallHeight = 3f;

	[Header("Textures")]
	public Texture2D wallTexture;
	public Texture2D floorTexture;
	public Color wallTint = Color.white;
	public Color floorTint = Color.white;
	public float textureScale = 1f;

	[Header("Player Spawn")]
	public bool spawnPlayerAtStart = true;
	public GameObject playerPrefab;

	private int[,] maze;
	private Material wallMaterial;
	private Material floorMaterial;
	private Vector2Int startPosition;

	void Start()
	{
		CreateMaterials();
		GenerateMaze();
		BuildMazeGeometry();
        
		if (spawnPlayerAtStart && playerPrefab != null)
		{
			SpawnPlayer();
		}
	}

	void CreateMaterials()
	{
		// Create wall material
		wallMaterial = new Material(Shader.Find("Standard"));
		wallMaterial.color = wallTint;
        
		if (wallTexture != null)
		{
			wallMaterial.mainTexture = wallTexture;
		}
        
		wallMaterial.SetFloat("_Metallic", 0.1f);
		wallMaterial.SetFloat("_Glossiness", 0.3f);

		// Create floor material
		floorMaterial = new Material(Shader.Find("Standard"));
		floorMaterial.color = floorTint;
        
		if (floorTexture != null)
		{
			floorMaterial.mainTexture = floorTexture;
		}
        
		floorMaterial.SetFloat("_Metallic", 0f);
		floorMaterial.SetFloat("_Glossiness", 0.2f);
	}

	void GenerateMaze()
	{
		maze = new int[width, height];
        
		// Initialize all cells as walls
		for (int x = 0; x < width; x++)
		{
			for (int y = 0; y < height; y++)
			{
				maze[x, y] = 1;
			}
		}

		// Generate maze using recursive backtracking
		Stack<Vector2Int> stack = new Stack<Vector2Int>();
		startPosition = new Vector2Int(1, 1);
		maze[startPosition.x, startPosition.y] = 0;
		stack.Push(startPosition);

		Vector2Int[] directions = {
			new Vector2Int(0, 2),  // Up
			new Vector2Int(2, 0),  // Right
			new Vector2Int(0, -2), // Down
			new Vector2Int(-2, 0)  // Left
		};

		while (stack.Count > 0)
		{
			Vector2Int current = stack.Peek();
			List<Vector2Int> neighbors = new List<Vector2Int>();

			// Find unvisited neighbors
			foreach (Vector2Int dir in directions)
			{
				Vector2Int next = current + dir;
				if (next.x > 0 && next.x < width - 1 && next.y > 0 && next.y < height - 1 && maze[next.x, next.y] == 1)
				{
					neighbors.Add(next);
				}
			}

			if (neighbors.Count > 0)
			{
				// Choose random neighbor
				Vector2Int chosen = neighbors[Random.Range(0, neighbors.Count)];
                
				// Remove wall between current and chosen
				Vector2Int wall = current + (chosen - current) / 2;
				maze[wall.x, wall.y] = 0;
				maze[chosen.x, chosen.y] = 0;
                
				stack.Push(chosen);
			}
			else
			{
				stack.Pop();
			}
		}
	}

	void BuildMazeGeometry()
	{
		// Create parent objects for organization
		GameObject wallsParent = new GameObject("Walls");
		wallsParent.transform.parent = transform;
		wallsParent.isStatic = true;

		GameObject floorParent = new GameObject("Floor");
		floorParent.transform.parent = transform;
		floorParent.isStatic = true;

		// Create floor
		CreateFloor(floorParent.transform);
		
		// Create ceiling
		CreateCeiling(floorParent.transform);

		// Create walls
		for (int x = 0; x < width; x++)
		{
			for (int y = 0; y < height; y++)
			{
				if (maze[x, y] == 1)
				{
					CreateWall(x, y, wallsParent.transform);
				}
			}
		}

		// Create outer boundary walls
		CreateBoundaryWalls(wallsParent.transform);
	}

	void CreateFloor(Transform parent)
	{
		GameObject floor = new GameObject("Floor");
		floor.transform.parent = parent;
		floor.layer = LayerMask.NameToLayer("Default");
		floor.isStatic = true;

		MeshFilter mf = floor.AddComponent<MeshFilter>();
		MeshRenderer mr = floor.AddComponent<MeshRenderer>();
        
		float floorWidth = width * cellSize;
		float floorDepth = height * cellSize;

		Mesh mesh = new Mesh();
        
		Vector3[] vertices = new Vector3[4];
		vertices[0] = new Vector3(0, 0, 0);
		vertices[1] = new Vector3(floorWidth, 0, 0);
		vertices[2] = new Vector3(0, 0, floorDepth);
		vertices[3] = new Vector3(floorWidth, 0, floorDepth);

		int[] triangles = new int[6] { 0, 2, 1, 2, 3, 1 };

		Vector2[] uvs = new Vector2[4];
		uvs[0] = new Vector2(0, 0);
		uvs[1] = new Vector2(width * textureScale, 0);
		uvs[2] = new Vector2(0, height * textureScale);
		uvs[3] = new Vector2(width * textureScale, height * textureScale);

		mesh.vertices = vertices;
		mesh.triangles = triangles;
		mesh.uv = uvs;
		mesh.RecalculateNormals();

		mf.mesh = mesh;
		mr.material = floorMaterial;

		// Add collider for walking
		MeshCollider mc = floor.AddComponent<MeshCollider>();
		mc.sharedMesh = mesh;
	}

	void CreateWall(int x, int y, Transform parent)
	{
		GameObject wall = new GameObject($"Wall_{x}_{y}");
		wall.transform.parent = parent;
		wall.transform.position = new Vector3(x * cellSize + cellSize / 2, wallHeight / 2, y * cellSize + cellSize / 2);
		wall.layer = LayerMask.NameToLayer("Default");
		wall.isStatic = true;

		MeshFilter mf = wall.AddComponent<MeshFilter>();
		MeshRenderer mr = wall.AddComponent<MeshRenderer>();
		BoxCollider bc = wall.AddComponent<BoxCollider>();

		// Create cube mesh
		Mesh mesh = CreateCubeMesh(cellSize, wallHeight, cellSize);
		mf.mesh = mesh;
		mr.material = wallMaterial;

		bc.size = new Vector3(cellSize, wallHeight, cellSize);
	}
	
	void CreateCeiling(Transform parent)
	{
		GameObject ceiling = new GameObject("Ceiling");
		ceiling.transform.parent = parent;
		ceiling.layer = LayerMask.NameToLayer("Default");
		ceiling.isStatic = true;

		MeshFilter mf = ceiling.AddComponent<MeshFilter>();
		MeshRenderer mr = ceiling.AddComponent<MeshRenderer>();
    
		float ceilingWidth = width * cellSize;
		float ceilingDepth = height * cellSize;
		float ceilingHeight = wallHeight;

		Mesh mesh = new Mesh();
    
		Vector3[] vertices = new Vector3[4];
		vertices[0] = new Vector3(0, ceilingHeight, 0);
		vertices[1] = new Vector3(ceilingWidth, ceilingHeight, 0);
		vertices[2] = new Vector3(0, ceilingHeight, ceilingDepth);
		vertices[3] = new Vector3(ceilingWidth, ceilingHeight, ceilingDepth);

		int[] triangles = new int[6] { 0, 1, 2, 1, 3, 2 };

		Vector2[] uvs = new Vector2[4];
		uvs[0] = new Vector2(0, 0);
		uvs[1] = new Vector2(1, 0);
		uvs[2] = new Vector2(0, 1);
		uvs[3] = new Vector2(1, 1);

		mesh.vertices = vertices;
		mesh.triangles = triangles;
		mesh.uv = uvs;
		mesh.RecalculateNormals();

		mf.mesh = mesh;
    
		// Create black material for ceiling
		Material ceilingMaterial = new Material(Shader.Find("Standard"));
		ceilingMaterial.color = Color.black;
		ceilingMaterial.SetFloat("_Metallic", 0f);
		ceilingMaterial.SetFloat("_Glossiness", 0f);
    
		mr.material = ceilingMaterial;
	}

	void CreateBoundaryWalls(Transform parent)
	{
		float thickness = 0.5f;
		float floorWidth = width * cellSize;
		float floorDepth = height * cellSize;

		// North wall
		CreateBoundaryWall("BoundaryNorth", parent, new Vector3(floorWidth / 2, wallHeight / 2, floorDepth + thickness / 2), new Vector3(floorWidth + thickness * 2, wallHeight, thickness));
        
		// South wall
		CreateBoundaryWall("BoundarySouth", parent, new Vector3(floorWidth / 2, wallHeight / 2, -thickness / 2), new Vector3(floorWidth + thickness * 2, wallHeight, thickness));
        
		// East wall
		CreateBoundaryWall("BoundaryEast", parent, new Vector3(floorWidth + thickness / 2, wallHeight / 2, floorDepth / 2), new Vector3(thickness, wallHeight, floorDepth));
        
		// West wall
		CreateBoundaryWall("BoundaryWest", parent, new Vector3(-thickness / 2, wallHeight / 2, floorDepth / 2), new Vector3(thickness, wallHeight, floorDepth));
	}

	void CreateBoundaryWall(string name, Transform parent, Vector3 position, Vector3 size)
	{
		GameObject wall = new GameObject(name);
		wall.transform.parent = parent;
		wall.transform.position = position;
		wall.isStatic = true;

		MeshFilter mf = wall.AddComponent<MeshFilter>();
		MeshRenderer mr = wall.AddComponent<MeshRenderer>();
		BoxCollider bc = wall.AddComponent<BoxCollider>();

		Mesh mesh = CreateCubeMesh(size.x, size.y, size.z);
		mf.mesh = mesh;
		mr.material = wallMaterial;

		bc.size = size;
	}

	Mesh CreateCubeMesh(float width, float height, float depth)
	{
		Mesh mesh = new Mesh();

		float w = width / 2;
		float h = height / 2;
		float d = depth / 2;

		Vector3[] vertices = new Vector3[24];
    
		// Front face
		vertices[0] = new Vector3(-w, -h, d);
		vertices[1] = new Vector3(w, -h, d);
		vertices[2] = new Vector3(w, h, d);
		vertices[3] = new Vector3(-w, h, d);
    
		// Back face
		vertices[4] = new Vector3(w, -h, -d);
		vertices[5] = new Vector3(-w, -h, -d);
		vertices[6] = new Vector3(-w, h, -d);
		vertices[7] = new Vector3(w, h, -d);
    
		// Top face
		vertices[8] = new Vector3(-w, h, d);
		vertices[9] = new Vector3(w, h, d);
		vertices[10] = new Vector3(w, h, -d);
		vertices[11] = new Vector3(-w, h, -d);
    
		// Bottom face
		vertices[12] = new Vector3(-w, -h, -d);
		vertices[13] = new Vector3(w, -h, -d);
		vertices[14] = new Vector3(w, -h, d);
		vertices[15] = new Vector3(-w, -h, d);
    
		// Right face
		vertices[16] = new Vector3(w, -h, d);
		vertices[17] = new Vector3(w, -h, -d);
		vertices[18] = new Vector3(w, h, -d);
		vertices[19] = new Vector3(w, h, d);
    
		// Left face
		vertices[20] = new Vector3(-w, -h, -d);
		vertices[21] = new Vector3(-w, -h, d);
		vertices[22] = new Vector3(-w, h, d);
		vertices[23] = new Vector3(-w, h, -d);

		int[] triangles = new int[36];
    
		// Front face (counter-clockwise)
		triangles[0] = 0; triangles[1] = 1; triangles[2] = 3;
		triangles[3] = 1; triangles[4] = 2; triangles[5] = 3;
    
		// Back face (counter-clockwise)
		triangles[6] = 4; triangles[7] = 5; triangles[8] = 7;
		triangles[9] = 5; triangles[10] = 6; triangles[11] = 7;
    
		// Top face (counter-clockwise)
		triangles[12] = 8; triangles[13] = 9; triangles[14] = 11;
		triangles[15] = 9; triangles[16] = 10; triangles[17] = 11;
    
		// Bottom face (counter-clockwise)
		triangles[18] = 12; triangles[19] = 13; triangles[20] = 15;
		triangles[21] = 13; triangles[22] = 14; triangles[23] = 15;
    
		// Right face (counter-clockwise)
		triangles[24] = 16; triangles[25] = 17; triangles[26] = 19;
		triangles[27] = 17; triangles[28] = 18; triangles[29] = 19;
    
		// Left face (counter-clockwise)
		triangles[30] = 20; triangles[31] = 21; triangles[32] = 23;
		triangles[33] = 21; triangles[34] = 22; triangles[35] = 23;

		Vector2[] uvs = new Vector2[24];
		for (int i = 0; i < 6; i++)
		{
			int idx = i * 4;
			uvs[idx] = new Vector2(0, 0);
			uvs[idx + 1] = new Vector2(textureScale, 0);
			uvs[idx + 2] = new Vector2(textureScale, textureScale);
			uvs[idx + 3] = new Vector2(0, textureScale);
		}

		mesh.vertices = vertices;
		mesh.triangles = triangles;
		mesh.uv = uvs;
		mesh.RecalculateNormals();

		return mesh;
	}

	void SpawnPlayer()
	{
		// Spawn player at the start position (center of the first open cell)
		Vector3 spawnPos = new Vector3(
			startPosition.x * cellSize + cellSize / 2,
			1.8f, // Standard character controller height
			startPosition.y * cellSize + cellSize / 2
		);

		GameObject player = Instantiate(playerPrefab, spawnPos, Quaternion.identity);
		player.name = "Player";
	}

	// Helper method to manually spawn player if needed
	public Vector3 GetStartPosition()
	{
		return new Vector3(
			startPosition.x * cellSize + cellSize / 2,
			1.8f,
			startPosition.y * cellSize + cellSize / 2
		);
	}
	
	public int GetMazeCell(int x, int y)
	{
		if (x >= 0 && x < width && y >= 0 && y < height)
		{
			return maze[x, y];
		}
		return 1; // Return wall for out of bounds
	}

	public Vector3 GetExitPosition()
	{
		// Return position of furthest corner from start
		return new Vector3((width - 2) * cellSize + cellSize / 2, 1f, (height - 2) * cellSize + cellSize / 2);
	}
}